import { getCartProductFormLS } from "../getCartProduct";
import { updateCartValue } from "./updateCartValue";

getCartProductFormLS();
export const addToCart = (event, id, stock) => {

    let arrLocalStorageProduct = getCartProductFormLS();
    const currentProdElem = document.querySelector(`#card${id}`);
    console.log(currentProdElem)
    let quantity = currentProdElem.querySelector(".productQuantity").innerText;
    let price = currentProdElem.querySelector(".productPrice").innerText;
    //console.log(qunatity, price);
    price = price.replace("₹", "");

    let existingProd = arrLocalStorageProduct.find((curProd) => curProd.id === id);

    if (existingProd && quantity > 1) {
        quantity = Number(existingProd.quantity) + Number(quantity);
        price = Number(price * quantity);
        let updatedCart = { id, quantity, price }

        updatedCart = arrLocalStorageProduct.map((curProd) => {
            return (curProd.id === id) ? updatedCart : curProd;
        });
        localStorage.setItem("cartProductLS", JSON.stringify(updatedCart));
    }

    if (existingProd) {
        //alert("This product already exit");
        return false;
    }

    price = Number(price * quantity);
    quantity = Number(quantity);

    let updatedCart = { id, quantity, price }
    arrLocalStorageProduct.push({ id, quantity, price });

    console.log(updatedCart);

    localStorage.setItem("cartProductLS", JSON.stringify(arrLocalStorageProduct))

    updateCartValue(arrLocalStorageProduct);


}